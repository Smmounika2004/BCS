OFFICE EMAIL TRANSFER - ALL PROJECT FILES AS TEXT

This ZIP contains 105 original project files, each encoded as Base64 in a numbered .txt file. No original .py/.html/.js/.css/.png/.db files appear in this email ZIP.

1. Send BCS_V3_Review6_ALL_FILES_AS_TXT_EMAIL.zip via approved company email.
2. On office PC, extract the ZIP.
3. Open the extracted BCS_V3_TEXT folder.
4. Rename RESTORE_FILES.py.txt to RESTORE_FILES.py (enable File Explorer > View > File name extensions).
5. Open a Command Prompt inside BCS_V3_TEXT and run: python RESTORE_FILES.py
6. The script restores ../BCS_V3 with the original names, extensions and folders, and verifies SHA-256 hashes for all files.
7. Open restored BCS_V3 in PyCharm. Install requirements from approved offline packages if necessary, then follow START_HERE.txt.
8. Hard-refresh browser Ctrl+F5 to clear cached JS/CSS.

IMPORTANT: This is Base64 text, not plain readable source. Restoration is mandatory. Email gateways can still block ZIP attachments according to company policy; only use approved transfer methods.
